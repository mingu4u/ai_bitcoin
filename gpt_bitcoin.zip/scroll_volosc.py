from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import chromedriver_autoinstaller
import time
import os
import logging
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException, WebDriverException, NoSuchElementException


def setup_driver():
    try:
        # 크롬 브라우저 버전 확인 및 맞는 ChromeDriver 설치
        chromedriver_autoinstaller.install()
        
        chrome_options = Options()
        chrome_options.add_argument('--start-maximized')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_experimental_option('excludeSwitches', ['enable-logging', 'enable-automation'])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # User-Agent 설정
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
        
        driver = webdriver.Chrome(options=chrome_options)
        
        # JavaScript 코드로 웹드라이버 감지 방지
        driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
            'source': '''
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                })
            '''
        })
        
        return driver
    except Exception as e:
        print(f"드라이버 설정 중 에러 발생: {str(e)}")
        raise

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def click_element_by_xpath(driver, xpath, element_name, wait_time=10):
    try:
        element = WebDriverWait(driver, wait_time).until(
            EC.presence_of_element_located((By.XPATH, xpath))
        )
        # 요소가 뷰포트에 보일 때까지 스크롤
        driver.execute_script("arguments[0].scrollIntoView(true);", element)
        # 요소가 클릭 가능할 때까지 대기
        element = WebDriverWait(driver, wait_time).until(
            EC.element_to_be_clickable((By.XPATH, xpath))
        )
        element.click()
        logger.info(f"{element_name} 클릭 완료")
        time.sleep(2)  # 클릭 후 잠시 대기
    except TimeoutException:
        logger.error(f"{element_name} 요소를 찾는 데 시간이 초과되었습니다.")
    except ElementClickInterceptedException:
        logger.error(f"{element_name} 요소를 클릭할 수 없습니다. 다른 요소에 가려져 있을 수 있습니다.")
    except NoSuchElementException:
        logger.error(f"{element_name} 요소를 찾을 수 없습니다.")
    except Exception as e:
        logger.error(f"{element_name} 클릭 중 오류 발생: {e}")

def click_volume_osc():
    driver = None
    try:
        driver = setup_driver()
        
        # 페이지 로드
        print("페이지 로딩 중...")
        driver.get("https://upbit.com/full_chart?code=CRIX.UPBIT.KRW-BTC")
        
        # 충분한 로딩 시간 대기
        time.sleep(4)
        print("페이지 로딩 완료")
        
        # 지표 탭 클릭
        print("지표 탭 찾는 중...")
        try:
            # 지표 메뉴 클릭
            click_element_by_xpath(
                driver,
                "/html/body/div[1]/div[2]/div[3]/span/div/div/div[1]/div/div/cq-menu[3]",
                "지표 메뉴"
            )
            print("지표 탭 클릭 완료")
            time.sleep(3)
        except Exception as e:
            print(f"지표 탭 클릭 실패: {str(e)}")
            raise
        
        # 스크롤 컨테이너 찾기
        print("스크롤 컨테이너 찾는 중...")
        scroll_container = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "cq-scroll"))
        )
        
        # Volume OSC 찾을 때까지 천천히 스크롤
        print("Volume OSC 찾는 중...")
        found = False
        for i in range(15):  # 스크롤 시도 횟수 증가
            driver.execute_script(
                "arguments[0].scrollTop += 80;",  # 스크롤 간격 줄임
                scroll_container
            )
            time.sleep(0.5)  # 대기 시간 증가
            
            try:
                click_element_by_xpath(
                    driver,
                    "/html/body/div[1]/div[2]/div[3]/span/div/div/div[1]/div/div/cq-menu[3]/cq-menu-dropdown/cq-scroll/cq-studies/cq-studies-content/cq-item[108]",
                    "Vol OSC"
                )
                print("Volume OSC 클릭 성공!")
                found = True
                screenshot_path = os.path.join(os.getcwd(), "upbit_screenshot.png")
                driver.save_screenshot(screenshot_path)
                print(f"업비트 스크린샷 저장 위치: {screenshot_path}")
                break
            except:
                continue
        
        if not found:
            print("Volume OSC를 찾지 못했습니다.")
        
        time.sleep(3)
        
    except Exception as e:
        print(f"실행 중 에러 발생: {str(e)}")
        if driver:
            screenshot_path = os.path.join(os.getcwd(), "error_screenshot.png")
            driver.save_screenshot(screenshot_path)
            print(f"에러 스크린샷 저장 위치: {screenshot_path}")
    finally:
        if driver:
            driver.quit()

if __name__ == "__main__":
    # 크롬 드라이버 버전 출력
    print(f"크롬 드라이버 경로: {chromedriver_autoinstaller.get_chrome_version()}")
    click_volume_osc()
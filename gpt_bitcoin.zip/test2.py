import pickle
from selenium.webdriver.common.action_chains import ActionChains
import logger
import os
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException, WebDriverException, NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from webdriver_manager.drivers.chrome import ChromeDriver
from selenium.webdriver.chrome.options import Options
import logging
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from PIL import Image
import io
from datetime import datetime
import base64
from selenium_stealth import stealth
import time
import win32api, win32con
import random

# def save_cookies(driver, path):
#     """쿠키 저장"""
#     with open(path, 'wb') as filehandler:
#         pickle.dump(driver.get_cookies(), filehandler)
#     print(f"쿠키가 저장되었습니다: {path}")  # logger 대신 print 사용


def setup_chrome_options():
    chrome_options = Options()
    # chrome_options.add_argument("--headless")  # 디버깅을 위해 헤드리스 모드 비활성화
    chrome_options.add_argument("disable-blink-features=AutomationControlled")  # 자동화 탐지 방지    
    chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument('--disable-infobars')
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])  # 자동화 표시 제거
    chrome_options.add_experimental_option('useAutomationExtension', False)  # 자동화 확장 기능 사용 안 함
    chrome_options.add_experimental_option("detach", True)  # 브라우저가 자동으로 닫히는 것을 방지
    chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
    return chrome_options

def create_driver():
    logger.info("ChromeDriver 설정 중...")
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=setup_chrome_options())
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    # CDP 명령어로 자동화 플래그 제거
    driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
        'source': '''
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
            delete window.cdc_adoQpoasnfa76pfcZLmcWfl_Promise;
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
        '''
    })
    # 페이지 언로드 이벤트 비활성화
    driver.execute_script("""
    Object.defineProperty(window, 'onbeforeunload', {
        get: function() {},
        set: function() {}
    });
    """)
    stealth(driver,
        languages=["en-US", "en"],
        vendor="Google Inc.",
        platform="Win32",
        webgl_vendor="Intel Inc.",
        renderer="Intel Iris OpenGL Engine",
        fix_hairline=True,
        )
    return driver

## old
# def save_cookies(driver, filename="tradingview_cookies.pkl"):
#     """쿠키 저장"""
#     # 현재 작업 디렉토리에 파일 저장
#     current_dir = os.getcwd()
#     file_path = os.path.join(current_dir, filename)
    
#     with open(file_path, 'wb') as filehandler:
#         pickle.dump(driver.get_cookies(), filehandler)
#     print(f"쿠키가 저장되었습니다: {file_path}")

## new
def save_cookies(driver, filename="tradingview_cookies.pkl"):
    """쿠키를 딕셔너리 형태로 변환하여 저장"""
    cookies = []
    for cookie in driver.get_cookies():
        cookie_dict = {
            'name': cookie.get('name'),
            'value': cookie.get('value'),
            'domain': cookie.get('domain'),
            'path': cookie.get('path'),
            'expiry': cookie.get('expiry'),
            'secure': cookie.get('secure', False),
            'httpOnly': cookie.get('httpOnly', False)
        }
        cookies.append(cookie_dict)
    
    current_dir = os.getcwd()
    file_path = os.path.join(current_dir, filename)
    
    with open(file_path, 'wb') as filehandler:
        pickle.dump(cookies, filehandler)
    print(f"쿠키가 저장되었습니다: {file_path}")



## old
# def load_cookies(driver, filename="tradingview_cookies.pkl"):
#    """쿠키 로드"""
#    # 현재 작업 디렉토리에서 파일 로드
#    current_dir = os.getcwd()
#    file_path = os.path.join(current_dir, filename)
   
#    if os.path.exists(file_path):
#        with open(file_path, 'rb') as cookiesfile:
#            cookies = pickle.load(cookiesfile)
#            for cookie in cookies:
#                driver.add_cookie(cookie)
#        print(f"쿠키를 로드했습니다: {file_path}")
#        return True
#    print(f"쿠키 파일을 찾을 수 없습니다: {file_path}")
#    return False

def check_login_status(driver):
    """로그인 상태 확인"""
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, "logged-in-user-menu-button")))
        return True
    except:
        return False


def login_with_cookies():
    try:
        driver = create_driver()
        cookies_path = "my_cookies.pkl"
        
        # 먼저 도메인에 접속 (쿠키 설정을 위해 필요)
        driver.get("https://www.tradingview.com/accounts/signin/")
        time.sleep(2)
        
        # 저장된 쿠키가 있다면 로드
        if load_cookies(driver, cookies_path):
            driver.refresh()  # 쿠키 적용을 위한 새로고침
            time.sleep(3)
            
            # 로그인 상태 확인
            if check_login_status(driver):
                print("쿠키를 통한 로그인 성공")
                return driver
        return driver
        
    except Exception as e:
        print(f"로그인 중 예외 발생: {e}")  # logger 대신 print 사용
        return None
## new
# def load_cookies(driver, filename="tradingview_cookies.pkl"):
#     """저장된 쿠키 딕셔너리를 로드하여 브라우저에 추가"""
#     current_dir = os.getcwd()
#     file_path = os.path.join(current_dir, filename)
    
#     if os.path.exists(file_path):
#         with open(file_path, 'rb') as cookiesfile:
#             cookies = pickle.load(cookiesfile)
#             for cookie in cookies:
#                 try:
#                     # expiry가 float인 경우 int로 변환
#                     if 'expiry' in cookie and cookie['expiry'] is not None:
#                         cookie['expiry'] = int(cookie['expiry'])
#                     driver.add_cookie(cookie)
#                 except Exception as e:
#                     print(f"쿠키 추가 중 오류 발생: {e}")
#                     continue
#         print(f"쿠키를 로드했습니다: {file_path}")
#         return True
#     print(f"쿠키 파일을 찾을 수 없습니다: {file_path}")
#     return False

def load_cookies(driver, filename="tradingview_cookies.pkl"):
    """저장된 쿠키를 로드하여 브라우저에 추가"""
    current_dir = os.getcwd()
    file_path = os.path.join(current_dir, filename)
    
    if os.path.exists(file_path):
        with open(file_path, 'rb') as cookiesfile:
            try:
                cookies = pickle.load(cookiesfile)
                for cookie in cookies:
                    try:
                        # Cookie 객체인 경우 딕셔너리로 변환
                        if not isinstance(cookie, dict):
                            cookie = {
                                'name': cookie.name,
                                'value': cookie.value,
                                'domain': cookie.domain,
                                'path': cookie.path,
                                'secure': cookie.secure,
                                'expiry': cookie.expires
                            }
                        
                        # expiry가 float인 경우 int로 변환
                        if 'expiry' in cookie and cookie['expiry'] is not None:
                            cookie['expiry'] = int(cookie['expiry'])
                            
                        # 불필요한 필드 제거
                        cookie_dict = {
                            'name': cookie.get('name'),
                            'value': cookie.get('value'),
                            'domain': cookie.get('domain'),
                            'path': cookie.get('path'),
                            'secure': cookie.get('secure', False)
                        }
                        if 'expiry' in cookie:
                            cookie_dict['expiry'] = cookie['expiry']
                            
                        driver.add_cookie(cookie_dict)
                    except Exception as e:
                        print(f"개별 쿠키 추가 중 오류 발생: {str(e)}")
                        continue
                        
                print(f"쿠키를 로드했습니다: {file_path}")
                return True
            except Exception as e:
                print(f"쿠키 파일 로드 중 오류 발생: {str(e)}")
                return False
                
    print(f"쿠키 파일을 찾을 수 없습니다: {file_path}")
    return False




def capture_and_encode_screenshot(driver):
    try:
        # 스크린샷 캡처
        png = driver.get_screenshot_as_png()
        
        # PIL Image로 변환
        img = Image.open(io.BytesIO(png))
        
        # 이미지 리사이즈 (OpenAI API 제한에 맞춤)
        img.thumbnail((2000, 2000))
        
        # 현재 시간을 파일명에 포함
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"upbit_chart_{current_time}.png"
        
        # 현재 스크립트의 경로를 가져옴
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 파일 저장 경로 설정
        file_path = os.path.join(script_dir, filename)
        
        # 이미지 파일로 저장
        img.save(file_path)
        logger.info(f"스크린샷이 저장되었습니다: {file_path}")
        
        # 이미지를 바이트로 변환
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        
        # base64로 인코딩
        base64_image = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        return base64_image, file_path
    except Exception as e:
        logger.error(f"스크린샷 캡처 및 인코딩 중 오류 발생: {e}")
        return None, None



logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# driver = login_with_cookies()

# try:
#     driver.get("https://kr.tradingview.com/chart/QYZJBUKS/?symbol=BITHUMB%3ABTCKRW")
#     time.sleep(5)  # 페이지 로딩 대기 시간 증가
#     chart_image, saved_file_path = capture_and_encode_screenshot(driver)
#     logger.info(f"스크린샷 캡처 완료. 저장된 파일 경로: {saved_file_path}")
# except WebDriverException as e:
#     logger.error(f"WebDriver 오류 발생: {e}")
#     chart_image, saved_file_path = None, None
# except Exception as e:
#     logger.error(f"차트 캡처 중 오류 발생: {e}")
#     chart_image, saved_file_path = None, None
# finally:
#     if driver:
#         driver.quit()







        # # 쿠키로 로그인 실패시 일반 로그인 진행
        # driver.get("https://www.tradingview.com/accounts/signin/")
        # wait = WebDriverWait(driver, 60)
        
        # wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='Email']"))).click()
        # time.sleep(1)
        # wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[name='id_username']"))).send_keys(longInfo[0])
        # time.sleep(1)
        # wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[name='id_password']"))).send_keys(longInfo[1])
        # time.sleep(1)
        # wait.until(EC.element_to_be_clickable((By.XPATH, "//button[.//span[contains(., 'Sign in')]]"))).click()
        # time.sleep(5)

        
        # # 로그인 성공 후 쿠키 저장
        # time.sleep(5)  # 로그인 완료 대기
        # save_cookies(driver, cookies_path)



# driver = create_driver()
# longInfo = ["mingu4u@naver.com", "1m2i3n4g5u!"]
# # driver.get("https://kr.tradingview.com/#signin")
# driver.get("https://www.tradingview.com/accounts/signin/")
# wait=WebDriverWait(driver, 30)
# time.sleep(random.uniform(1, 3))
# # 또는 
# # 저장된 쿠키가 있다면 로드
# if load_cookies(driver, "my_cookies.pkl"):
#     driver.refresh()  # 쿠키 적용을 위한 새로고침
#     time.sleep(3)

#     # 로그인 상태 확인
#     if check_login_status(driver):
#         print("쿠키를 통한 로그인 성공")
#         return driver
# wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='Email']"))).click()



# wait.until(EC.element_to_be_clickable((By.XPATH ,"/html/body/div[/8div/div/div[1]/div/div[2]/div[2]/div/div/div[1]/button[1]"))).click()
# time.sleep(random.uniform(1, 3))
# wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[name='id_username']"))).send_keys(longInfo[0])
# time.sleep(random.uniform(1, 3))
# wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[name='id_password']"))).send_keys(longInfo[1])
# time.sleep(random.uniform(1, 3))
# wait.until(EC.element_to_be_clickable((By.XPATH, "//button[.//span[contains(., 'Sign in')]]"))).click()



driver = create_driver()
driver.get("https://kr.tradingview.com/#main-market-summary")
time.sleep(5)
# save_cookies(driver, "cookies_test_ok.pkl")

load_cookies(driver, "cookies_test_ok.pkl")
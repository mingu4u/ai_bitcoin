import browser_cookie3
import json
import pickle
from pathlib import Path
import datetime
import sys
import os
import ctypes
import psutil
import time
import subprocess

def is_admin():
    """현재 프로세스가 관리자 권한으로 실행 중인지 확인합니다."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    """스크립트를 관리자 권한으로 다시 실행합니다."""
    try:
        script = os.path.abspath(sys.argv[0])
        params = sys.argv[1:]
        
        if sys.platform == 'win32':
            python_exe = sys.executable
            subprocess.run(['powershell', 'Start-Process', python_exe, '-ArgumentList', f'"{script}"', '-Verb', 'RunAs'], 
                         capture_output=True, 
                         text=True,
                         check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"관리자 권한 실행 실패: {e}")
        return False
    except Exception as e:
        print(f"오류 발생: {e}")
        return False

def close_chrome():
    """실행 중인 Chrome 프로세스를 종료합니다."""
    closed = False
    for proc in psutil.process_iter(['name']):
        try:
            if 'chrome' in proc.info['name'].lower():
                proc.terminate()
                closed = True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    if closed:
        time.sleep(2)  # 프로세스가 완전히 종료되기를 기다림
    return closed

def get_chrome_profile_paths():
    """사용 가능한 Chrome 프로필의 쿠키 파일 경로들을 반환합니다."""
    try:
        local_app_data = os.getenv('LOCALAPPDATA')
        chrome_path = os.path.join(local_app_data, 'Google', 'Chrome', 'User Data')
        
        profiles = []
        if os.path.exists(chrome_path):
            # 기본 프로필
            default_profile = os.path.join(chrome_path, 'Default', 'Network', 'Cookies')
            if os.path.exists(default_profile):
                profiles.append(default_profile)
            
            # 추가 프로필들
            for item in os.listdir(chrome_path):
                if item.startswith('Profile '):
                    profile_path = os.path.join(chrome_path, item, 'Network', 'Cookies')
                    if os.path.exists(profile_path):
                        profiles.append(profile_path)
        
        return profiles
    except Exception as e:
        print(f"프로필 경로 검색 중 오류: {e}")
        return []

def save_browser_cookies(browser_name='chrome', output_path='cookies.pkl', format='pickle'):
    """지정된 브라우저의 현재 쿠키를 파일로 저장합니다."""
    try:
        if not is_admin():
            print("\n관리자 권한이 필요합니다. 관리자 권한으로 재실행합니다...")
            run_as_admin()
            return False

        print("\n관리자 권한으로 실행 중...")
        
        browser_functions = {
            'chrome': browser_cookie3.chrome,
            'firefox': browser_cookie3.firefox,
            'edge': browser_cookie3.edge,
            'safari': browser_cookie3.safari
        }
        
        if browser_name.lower() not in browser_functions:
            raise ValueError(f"지원하지 않는 브라우저입니다. 지원 브라우저: {', '.join(browser_functions.keys())}")
        
        if browser_name.lower() == 'chrome':
            # Chrome이 실행 중인지 확인하고 종료
            if close_chrome():
                print("실행 중이던 Chrome 브라우저를 종료했습니다.")
                time.sleep(2)
            
            # 사용 가능한 프로필의 쿠키 파일 확인
            cookie_files = get_chrome_profile_paths()
            if not cookie_files:
                raise ValueError("사용 가능한 Chrome 쿠키 파일을 찾을 수 없습니다.")
            
            # 모든 프로필에서 쿠키 수집
            all_cookies = []
            for cookie_file in cookie_files:
                try:
                    profile_name = os.path.basename(os.path.dirname(os.path.dirname(cookie_file)))
                    print(f"\n프로필 {profile_name}에서 쿠키를 추출하는 중...")
                    
                    # 쿠키 파일이 잠겨있을 수 있으므로 복사본 생성
                    temp_cookie_file = os.path.join(os.path.dirname(cookie_file), 'Cookies.tmp')
                    try:
                        with open(cookie_file, 'rb') as src, open(temp_cookie_file, 'wb') as dst:
                            dst.write(src.read())
                        profile_cookies = browser_cookie3.chrome(cookie_file=temp_cookie_file)
                    finally:
                        if os.path.exists(temp_cookie_file):
                            try:
                                os.remove(temp_cookie_file)
                            except:
                                pass
                    
                    for cookie in profile_cookies:
                        cookie_dict = {
                            'domain': cookie.domain,
                            'name': cookie.name,
                            'value': cookie.value,
                            'path': cookie.path,
                            'secure': cookie.secure,
                            'expires': str(datetime.datetime.fromtimestamp(cookie.expires)) if cookie.expires else None,
                            'profile': profile_name,
                            'raw_cookie': cookie
                        }
                        all_cookies.append(cookie_dict)
                except Exception as e:
                    print(f"프로필 {profile_name} 쿠키 처리 중 오류: {str(e)}")
                    continue
            
            if not all_cookies:
                raise ValueError("추출된 쿠키가 없습니다.")
            
            cookie_list = all_cookies
        else:
            # 다른 브라우저의 경우
            print(f"\n{browser_name} 브라우저의 쿠키를 추출하는 중...")
            cookies = browser_functions[browser_name.lower()]()
            cookie_list = []
            for cookie in cookies:
                cookie_dict = {
                    'domain': cookie.domain,
                    'name': cookie.name,
                    'value': cookie.value,
                    'path': cookie.path,
                    'secure': cookie.secure,
                    'expires': str(datetime.datetime.fromtimestamp(cookie.expires)) if cookie.expires else None,
                    'raw_cookie': cookie
                }
                cookie_list.append(cookie_dict)
        
        output_file = Path(output_path)
        
        if format.lower() == 'pickle':
            with output_file.open('wb') as f:
                pickle.dump(cookie_list, f)
        elif format.lower() == 'json':
            # JSON 저장 시 raw_cookie 객체 제외
            json_cookies = []
            for cookie in cookie_list:
                cookie_copy = cookie.copy()
                cookie_copy.pop('raw_cookie', None)
                json_cookies.append(cookie_copy)
            
            with output_file.open('w', encoding='utf-8') as f:
                json.dump(json_cookies, f, ensure_ascii=False, indent=2)
        else:
            raise ValueError("지원하지 않는 저장 형식입니다. 'pickle' 또는 'json'을 사용하세요.")
        
        print(f"\n{len(cookie_list)}개의 쿠키가 {output_path}에 저장되었습니다.")
        return True
        
    except Exception as e:
        print(f"\n오류 발생: {str(e)}")
        return False

def load_saved_cookies(input_path='cookies.pkl', format='pickle'):
    """저장된 쿠키 파일을 불러옵니다."""
    try:
        input_file = Path(input_path)
        
        if format.lower() == 'pickle':
            with input_file.open('rb') as f:
                cookies = pickle.load(f)
        elif format.lower() == 'json':
            with input_file.open('r', encoding='utf-8') as f:
                cookies = json.load(f)
        else:
            raise ValueError("지원하지 않는 파일 형식입니다. 'pickle' 또는 'json'을 사용하세요.")
            
        return cookies
    except Exception as e:
        print(f"\n쿠키 파일 로딩 중 오류 발생: {str(e)}")
        return None

def get_raw_cookies(cookies):
    """pickle로 저장된 쿠키에서 원본 쿠키 객체들을 추출합니다."""
    raw_cookies = []
    for cookie in cookies:
        if 'raw_cookie' in cookie:
            raw_cookies.append(cookie['raw_cookie'])
    return raw_cookies

if __name__ == "__main__":
    try:
        # 관리자 권한 확인
        if not is_admin():
            print("\n관리자 권한으로 실행이 필요합니다.")
            print("프로그램을 관리자 권한으로 다시 실행합니다...")
            if run_as_admin():
                sys.exit(0)
            else:
                print("관리자 권한으로 실행하지 못했습니다.")
                sys.exit(1)

        # 관리자 권한을 얻은 후의 코드
        browser_name = input("\n브라우저를 선택하세요 (chrome/firefox/edge/safari): ").lower()
        output_path = input("저장할 파일 경로를 입력하세요 (기본: cookies.pkl): ") or "cookies.pkl"
        format_type = input("저장 형식을 선택하세요 (pickle/json) (기본: pickle): ") or "pickle"
        
        print("\n주의: Chrome 브라우저를 선택한 경우, 실행 중인 Chrome이 자동으로 종료됩니다.")
        proceed = input("계속하시겠습니까? (y/n): ").lower()
        
        if proceed != 'y':
            print("프로그램을 종료합니다.")
            sys.exit(0)
        
        success = save_browser_cookies(browser_name, output_path, format_type)
        
        if success and format_type == 'pickle':
            print("\n저장된 쿠키를 확인합니다...")
            saved_cookies = load_saved_cookies(output_path, format_type)
            if saved_cookies:
                print(f"불러온 쿠키 개수: {len(saved_cookies)}")
                raw_cookies = get_raw_cookies(saved_cookies)
                print(f"원본 쿠키 객체 개수: {len(raw_cookies)}")
    
    except Exception as e:
        print(f"\n실행 중 오류 발생: {str(e)}")
    
    finally:
        print("\n프로그램을 종료하려면 Enter 키를 누르세요...")
        input()
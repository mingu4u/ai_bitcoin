
import os
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from webdriver_manager.drivers.chrome import ChromeDriver
from selenium.webdriver.chrome.options import Options
import logging
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from PIL import Image
import io
from datetime import datetime
import base64
from selenium_stealth import stealth
import time
import win32api, win32con
def setup_chrome_options():
    chrome_options = Options()
    # chrome_options.add_argument("--headless")  # 디버깅을 위해 헤드리스 모드 비활성화
    chrome_options.add_argument("disable-blink-features=AutomationControlled")  # 자동화 탐지 방지    
    chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])  # 자동화 표시 제거
    chrome_options.add_experimental_option('useAutomationExtension', False)  # 자동화 확장 기능 사용 안 함
    chrome_options.add_experimental_option("detach", True)  # 브라우저가 자동으로 닫히는 것을 방지
    chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
    return chrome_options

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# def capture_and_encode_screenshot(driver):
#     try:
#         # 스크린샷 캡처
#         png = driver.get_screenshot_as_png()
        
#         # PIL Image로 변환
#         img = Image.open(io.BytesIO(png))
        
#         # 이미지 리사이즈 (OpenAI API 제한에 맞춤)
#         img.thumbnail((2000, 2000))
        
#         # 현재 시간을 파일명에 포함
#         current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"upbit_chart_{current_time}.png"
        
#         # 현재 스크립트의 경로를 가져옴
#         script_dir = os.path.dirname(os.path.abspath(__file__))
        
#         # 파일 저장 경로 설정
#         file_path = os.path.join(script_dir, filename)
        
#         # 이미지 파일로 저장
#         img.save(file_path)
#         logger.info(f"스크린샷이 저장되었습니다: {file_path}")
        
#         # 이미지를 바이트로 변환
#         buffered = io.BytesIO()
#         img.save(buffered, format="PNG")
        
#         # base64로 인코딩
#         base64_image = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
#         return base64_image, file_path
#     except Exception as e:
#         logger.error(f"스크린샷 캡처 및 인코딩 중 오류 발생: {e}")
#         return None, None


def create_driver():
    logger.info("ChromeDriver 설정 중...")
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=setup_chrome_options())
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    # CDP 명령어로 자동화 플래그 제거
    driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
        'source': '''
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
            delete window.cdc_adoQpoasnfa76pfcZLmcWfl_Promise;
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
        '''
    })
    stealth(driver,
        languages=["en-US", "en"],
        vendor="Google Inc.",
        platform="Win32",
        webgl_vendor="Intel Inc.",
        renderer="Intel Iris OpenGL Engine",
        fix_hairline=True,
        )
    return driver


try:
    driver = create_driver()
    longInfo = ["mingu4u@naver.com", "1m2i3n4g5u!"]
    # driver.get("https://kr.tradingview.com/#signin")
    driver.get("https://www.tradingview.com/accounts/signin/")
    wait=WebDriverWait(driver, 30)
    wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='Email']"))).click()
    
    # wait.until(EC.element_to_be_clickable((By.XPATH ,"/html/body/div[/8div/div/div[1]/div/div[2]/div[2]/div/div/div[1]/button[1]"))).click()
    time.sleep(3)
    wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[name='id_username']"))).send_keys(longInfo[0])
    time.sleep(3)
    wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[name='id_password']"))).send_keys(longInfo[1])
    time.sleep(3)
    wait.until(EC.element_to_be_clickable((By.XPATH, "//button[.//span[contains(., 'Sign in')]]"))).click()


except Exception as e:
    logger.error(f"자동화 중 예외 발생: {e}")
